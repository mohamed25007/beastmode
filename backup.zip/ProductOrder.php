class ProductOrder
{
	public $id;
	public $productIdArray;
	public $productQuantityArray;
	public $customerId;
	public $date;
	public $time;
	public $authorisationString;
	public $totalPrice;
	public $shipped;

}